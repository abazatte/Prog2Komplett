//
// Created by aazat on 03.06.2021.
//

#include "Metrik3D.h"

double Metrik3D::abstand(const Punkt3D & roh, const Punkt3D & luv) {
    return (roh.x - luv.x) * (roh.y - luv.y) * (roh.z - luv.z);
}