//
// Created by aazat on 02.06.2021.
//

#ifndef TEST_OPERANDENPASSENNICHT_H
#define TEST_OPERANDENPASSENNICHT_H


class OperandenPassenNicht: public exception{

};


#endif //TEST_OPERANDENPASSENNICHT_H
