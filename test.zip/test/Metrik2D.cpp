//
// Created by aazat on 03.06.2021.
//

#include "Metrik2D.h"

double Metrik2D::abstand(const Punkt2D &ro, const Punkt2D &lu) {
    return (ro.x - lu.x) * (ro.y - lu.y);
}