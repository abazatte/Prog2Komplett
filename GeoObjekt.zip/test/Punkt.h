//
// Created by aazat on 02.06.2021.
//

#ifndef TEST_PUNKT_H
#define TEST_PUNKT_H
#include <string>
using namespace std;

class Punkt {
public:
    virtual string toString() = 0;
};


#endif //TEST_PUNKT_H
