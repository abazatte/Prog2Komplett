//
// Created by aazat on 02.06.2021.
//

#ifndef TEST_OPERANDENPASSENNICHT_H
#define TEST_OPERANDENPASSENNICHT_H


class OperandenPassenNicht: public std::exception {
public:
    OperandenPassenNicht() = default;
    ~OperandenPassenNicht() = default;
};


#endif //TEST_OPERANDENPASSENNICHT_H
