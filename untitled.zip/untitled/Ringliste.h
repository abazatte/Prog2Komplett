

#include <string>
#include <vector>

using namespace std;

class Ringliste {

public:
    vector<int> v{10};
    int lese;
    int schreibe;
    Ringliste(int i);
    Ringliste();
    Ringliste(Ringliste& r);

    string toString();

    bool operator==(Ringliste& a);

    Ringliste& operator<<(int zahl);
    Ringliste& operator<<(Ringliste& r);
    void operator+=(int i);

    int anzahlElemente();
};



