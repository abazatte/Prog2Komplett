
#include "Ringliste.h"
#include <vector>
#include <string>
#include <sstream>
#include <iostream>
#include <iomanip>
using namespace std;
Ringliste::Ringliste(){
    lese = 0;
    schreibe = 0;
}
Ringliste::Ringliste(int i) {
    v.resize(i);
    lese = 0;
    schreibe = 0;
}

Ringliste::Ringliste(Ringliste& r){
    v = r.v;
    lese = r.lese;
    schreibe = r.schreibe;
}

bool Ringliste::operator==(Ringliste& a) {
    string liste1 = toString();
    string liste2 = a.toString();
    return liste1 == liste2;
}

// operator<<
Ringliste& Ringliste::operator<<(int zahl) {
    if (anzahlElemente() == v.size()){
        lese = 1;
    }
    v[schreibe] = zahl;
    schreibe = (schreibe +1) % v.size();
    return *this;
}

string Ringliste::toString() {
    stringstream liste;
    liste << anzahlElemente() << "/" << v.size() << " | ";
    if(anzahlElemente()== 0){
        return liste.str();
    }
    int tmp {lese};
    do {
        liste << v[tmp] << " ";
        tmp = (tmp +1) % v.size();
    } while (tmp != schreibe);
    return liste.str();
}

int Ringliste::anzahlElemente(){
    int hilf {0};
    for (int i: v){
        if (i != 0){
            hilf++;
        }
    }
    return hilf;
}

void Ringliste::operator+=(int i){
    for (int j: v){
        if (j != 0){
            j+=i;
        }
    }
}

Ringliste& Ringliste::operator<<(Ringliste& l) {
    Ringliste tmpRing(l);
    for (int i = 0; i < tmpRing.v.size(); i++){
        if (tmpRing.v[i] != 0){
            operator<<(tmpRing.v[i]);
        }
    }
    return *this;
}