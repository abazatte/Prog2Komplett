
#ifndef FIFO_FIFOELEMENT_H
#define FIFO_FIFOELEMENT_H

#endif //FIFO_FIFOELEMENT_H
#include <iostream>
using std::string;

class FifoElement{
public:
    FifoElement * next;
    string myString;
    FifoElement(string text);
    ~ FifoElement();
};



