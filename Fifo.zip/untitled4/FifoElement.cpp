
#include "FifoElement.h"

FifoElement::FifoElement(string text) {
    this->myString = text;
    this->next = nullptr;
}

FifoElement::~ FifoElement() = default;

